<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'cohort', language 'fr', version '4.5'.
 *
 * @package     cohort
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addcohort'] = 'Ajouter une cohorte';
$string['allcohorts'] = 'Toutes les cohortes';
$string['anycohort'] = 'Tout';
$string['assign'] = 'Ajouter membres';
$string['assigncohorts'] = 'Attribuer des membres à des cohortes';
$string['assignto'] = 'Membres de la cohorte « {$a} »';
$string['backtocohorts'] = 'Retour aux cohortes';
$string['bulkadd'] = 'Ajouter à la cohorte';
$string['bulknocohort'] = 'Aucune cohorte disponible';
$string['categorynotfound'] = 'Soit la catégorie {$a} est introuvable, soit vous n’avez pas les permissions requises pour y créer une cohorte. Le contexte par défaut sera utilisé.';
$string['cohort'] = 'Cohorte';
$string['cohortmember'] = 'Membre de la cohorte';
$string['cohorts'] = 'Cohortes';
$string['cohortsin'] = '{$a} : cohortes disponibles';
$string['component'] = 'Source';
$string['contextcohortnotallowed'] = 'La cohorte <b>{$a}</b> n’est pas autorisée dans ce contexte.';
$string['contextnotfound'] = 'Soit le contexte {$a} est introuvable, soit vous n’avez pas les permissions requises pour y créer une cohorte. Le contexte par défaut sera utilisé.';
$string['csvcontainserrors'] = 'Des erreurs ont été détectées dans les données CSV. Voir les informations additionnelles ci-dessous.';
$string['csvcontainswarnings'] = 'Des avertissements ont été émis lors de l’analyse des données CSV. Voir les informations additionnelles ci-dessous.';
$string['csvextracolumns'] = 'Les colonnes <b>{$a}</b> seront ignorées.';
$string['currentusers'] = 'Utilisateurs actuels';
$string['currentusersmatching'] = 'Utilisateurs actuels correspondant à';
$string['defaultcontext'] = 'Contexte par défaut';
$string['delcohort'] = 'Supprimer cohorte';
$string['delcohortsconfirm'] = 'Cette opération supprimera les cohortes et toutes les données associées.';
$string['delcohortssuccess'] = 'Cohortes sélectionnées supprimées';
$string['delconfirm'] = 'Cette opération supprimera la cohorte « {$a} » et toutes les données associées.';
$string['delsuccess'] = 'Cohorte supprimée';
$string['description'] = 'Description';
$string['displayedrows'] = '{$a->displayed} rangées affichées sur {$a->total}.';
$string['duplicateidnumber'] = 'Une cohorte de même identifiant existe déjà';
$string['editcohort'] = 'Modifier cohorte';
$string['editcohortidnumber'] = 'Modifier l’Id de la cohorte';
$string['editcohortname'] = 'Modifier le nom de la cohorte';
$string['eventcohortcreated'] = 'Cohorte créée';
$string['eventcohortdeleted'] = 'Cohorte supprimée';
$string['eventcohortmemberadded'] = 'Utilisateur ajouté à une cohorte';
$string['eventcohortmemberremoved'] = 'Utilisateur retiré d’une cohorte';
$string['eventcohortupdated'] = 'Cohorte modifiée';
$string['external'] = 'Cohorte externe';
$string['idnumber'] = 'Identifiant cohorte';
$string['invalidtheme'] = 'Le thème de cohorte n’existe pas';
$string['memberofcohort'] = 'Membre de la cohorte';
$string['memberscount'] = 'Effectif de la cohorte';
$string['name'] = 'Nom';
$string['namecolumnmissing'] = 'Il y a un problème dans le format du fichier CSV. Veuillez vérifier qu’il comporte les noms corrects des colonnes. Pour ajouter de nouveaux utilisateurs à une cohorte, aller vers « Déposer des utilisateurs » dans l’administration du site.';
$string['namefieldempty'] = 'Le nom du champ ne peut pas être vide';
$string['newidnumberfor'] = 'Nouvel identifiant pour la cohorte {$a}';
$string['newnamefor'] = 'Nouveau nom pour la cohorte {$a}';
$string['nocomponent'] = 'Création manuelle';
$string['potusers'] = 'Utilisateurs potentiels';
$string['potusersmatching'] = 'Utilisateurs potentiels correspondants';
$string['preview'] = 'Prévisualisation';
$string['privacy:metadata:cohort_members'] = 'Informations sur la cohorte de l’utilisateur.';
$string['privacy:metadata:cohort_members:cohortid'] = 'L’identifiant de la cohorte';
$string['privacy:metadata:cohort_members:timeadded'] = 'L’horodatage de l’ajout de l’utilisateur à la cohorte';
$string['privacy:metadata:cohort_members:userid'] = 'L’identifiant de l’utilisateur associé à la cohorte';
$string['removeuserwarning'] = 'En retirant des utilisateurs de cohortes, la désinscription de ces utilisateurs de plusieurs cours pourrait survenir. Il pourrait s’ensuivre la suppression de réglages utilisateur, de notes, d’affiliation à des groupes et toute autre information utilisateur dans les cours concernés.';
$string['search'] = 'Rechercher';
$string['searchcohort'] = 'Rechercher une cohorte';
$string['selectcohort'] = 'Sélectionner cohorte';
$string['selectfromcohort'] = 'Sélectionner des membres de la cohorte';
$string['systemcohorts'] = 'Cohortes système';
$string['unknowncohort'] = 'Cohorte inconnue ({$a}) !';
$string['uploadcohorts'] = 'Déposer des cohortes';
$string['uploadcohorts_help'] = 'Des cohortes peuvent être déposées au moyen d’un fichier texte. Le format de ce fichier doit être le suivant :

* chaque ligne du fichier contient un enregistrement ;
* chaque enregistrement est une série de données séparées par le caractère de séparation sélectionné ;
* le seul champ requis est name ;
* les champs optionnels sont idnumber, description, descriptionformat, visible, context, category, category_id, category_idnumber, category_path.';
$string['uploadedcohorts'] = '{$a} cohortes déposées';
$string['useradded'] = 'Utilisateur ajouté à la cohorte « {$a} »';
$string['visible'] = 'Visible';
$string['visible_help'] = 'Les cohortes peuvent être vues par les utilisateurs disposant de la capacité « moodle/cohort:view » dans le contexte de la cohorte.<br />
Les cohortes visibles peuvent aussi être vues par les utilisateurs dans les cours enfants.';
